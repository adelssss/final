function setLanguage(lang) {
    document.querySelectorAll('[data-lang]').forEach(element => {
        if (element.getAttribute('data-lang') === lang) {
            element.style.display = 'block';
        } else {
            element.style.display = 'none';
        }
    });
}

window.onload = function() {
    var plane = document.getElementById('plane');
    var audio = document.getElementById('myAudio');
    var startButton = document.getElementById('startButton');

    function movePlane() {
        plane.style.transform = 'translate(calc(100vw + 100px), calc(100vh - 150px))';
    }
    function playAudioAndAnimation() {
        audio.play().then(() => {
            movePlane();
        }).catch(error => {
            console.error('Audio playback failed:', error);
        });
    }

    startButton.addEventListener('click', function() {
        playAudioAndAnimation();
        startButton.style.display = 'none';
    });
};


