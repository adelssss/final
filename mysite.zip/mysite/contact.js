document.addEventListener("DOMContentLoaded", function() {
    const questions = document.querySelectorAll('.question');
    const resultContainer = document.getElementById('result');
    const resultText = document.getElementById('result-text');
    const tourDescription = document.getElementById('tour-description');
    const tourImageContainer = document.getElementById('tour-image');

    let currentQuestion = 0;
    const userPreferences = [];
    questions.forEach((question, index) => {
        question.addEventListener('click', (e) => {
            const choice = e.target.dataset.choice;
            userPreferences.push(choice);
            showNextQuestion(index);
        });
    });

    function showNextQuestion(index) {
        questions[index].style.display = 'none';
        if (index + 1 < questions.length) {
            questions[index + 1].style.display = 'block';
        } else {
            showResult();
        }
    }
    
    function showResult() {
        resultContainer.style.display = 'block';
        const destination = userPreferences[0];
        const activity = userPreferences[1];
        const transportation = userPreferences[2];

        let tour;
        let tourImage;

        if (destination === 'beach' && activity === 'relaxing' && transportation === 'plane') {
            tour = 'Relaxing Beach Getaway in Maldives';
            tourImage = 'images/maldives.jpg';
        } else if (destination === 'mountain' && activity === 'adventurous' && transportation === 'car') {
            tour = 'Adventure Trekking in the Himalayas';
            tourImage = 'images/himalayas.jpg';
        } else if (destination === 'city' && activity === 'cultural' && transportation === 'train') {
            tour = 'Cultural Exploration in Europe';
            tourImage = 'images/europe.jpg';
        } else if (destination === 'beach' && activity === 'relaxing' && transportation === 'car') {
            tour = 'Coastal Road Trip to Florida';
            tourImage = 'images/florida.jpg';
        } else if (destination === 'city' && activity === 'relaxing' && transportation === 'train') {
            tour = 'Cultural Retreat in the Loire Valley, France';
            tourImage = 'images/france.jpg';
        } else {
            tour = 'Tour not available based on your preferences';
            tourImage = 'images/notavailable.jpg';
        }

        resultText.textContent = '';
        tourDescription.textContent = '';
        tourImageContainer.innerHTML = ''; 

        const img = document.createElement('img');
        img.src = tourImage;
        img.alt = tour;
        img.style.width = '200px'; 

        resultText.textContent = 'Your Ideal Tour:';
        tourDescription.textContent = tour;
        tourImageContainer.appendChild(img);
    }

    document.getElementById('registration-form').addEventListener('submit', function(event) {
        event.preventDefault();
        
        const username = document.getElementById('username').value;
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirm-password').value;

        if (password !== confirmPassword) {
            alert('Passwords do not match!');
            return;
        }

        if (!isValidEmail(email)) {
            alert('Please enter a valid email address!');
            return;
        }

        alert('Registration successful!');
        document.getElementById('registration-form').reset();
    });
    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
    
});
